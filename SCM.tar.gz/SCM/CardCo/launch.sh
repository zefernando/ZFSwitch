cd /u01/SCM/CardCo
nohup ./launch 192.168.1.2 32001 >launch.out &
#nohup ./launch 192.168.1.5 32001 >launch.out &
