killall -15 launch 192.168.1.2 32001
killall -15 log cardco.log 
killall -15 fmt
killall -15 auth
killall -15 paybal
killall -15 tcpclient 192.168.1.2 32001 
