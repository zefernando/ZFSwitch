ls > /tmp/q
