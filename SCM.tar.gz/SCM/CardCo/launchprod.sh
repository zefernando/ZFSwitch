cd /u01/SCMDES/CardCo
nohup ./launch 192.168.1.2 32001 >launch.out &
