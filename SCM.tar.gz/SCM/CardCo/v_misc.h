#define FMT_MTOC 25     
#define FMT_ATOI 20
#define FMT_ATOS 21
#define FMT_CTOM 22
#define FMT_CHAR 23
