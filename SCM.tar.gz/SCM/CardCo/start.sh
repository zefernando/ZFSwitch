./log cardco.log &
./fmt &
./auth &
./tcpclient 192.168.1.2 32001 &
