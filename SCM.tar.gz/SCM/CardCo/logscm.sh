/u01/SCM/CardCo/stop.sh
cat /dev/null > /u01/SCM/CardCo/fmt.log
cat /dev/null > /u01/SCM/CardCo/sqlnet.log
chown scm. /u01/SCM/CardCo/*.log
cat /dev/null > /u01/SCM/CardCo/launch.out
chown scm. /u01/SCM/CardCo/*.out
cat /dev/null > /u01/SCM/CardCo/logDir/cardco.log
cat /dev/null > /u01/SCM/CardCo/logDir/logtcp.log
chown scm. /u01/SCM/CardCo/logDir/*.log
cat /dev/null > /u01/SCM/CardCo/debug/areacomp.debug
cat /dev/null > /u01/SCM/CardCo/debug/auth.debug
cat /dev/null > /u01/SCM/CardCo/debug/extern.debug
cat /dev/null > /u01/SCM/CardCo/debug/paybal.debug
cat /dev/null > /u01/SCM/CardCo/debug/launch.debug
chown scm. /u01/SCM/CardCo/debug/*.debug

